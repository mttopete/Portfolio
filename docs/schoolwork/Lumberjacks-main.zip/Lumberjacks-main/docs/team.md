---
layout: default
title:  Team
---

# {{ page.title }}


## Anthony de Bem
***UCI Net ID***: adebem

## Mateo Topete
***UCI Net ID***: mttopete

## Stuart McClintock
***UCI Net ID***: semcclin
