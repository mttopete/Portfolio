---
layout: default
title: Proposal
---

# Summary

<p>
  Lumberjacks is a project in Malmo meant to optimize wood gathering in minecraft.
  Our goal is to create an AI that can learn to gather the most wood in the least amount of time by only punching trees.
  The agent will observe a 3d grid comparable to a player's default render distance.
  Upon every observation, the agent will decide which tree yields the most wood per time and begin gathering its wood.
</p>

# AI/ML Algorithms

Lumberjacks will utilize a reinforcement learning model that improves wood gathering behavior over time.

# Evaluation plan

<p>
  The success of the agent will be measured by how much wood it gathers within a time frame.
  Our base goal would be to produce a model that can determine the steps necessary to gather wood.
  From there, we will aim to raise the number of wood blocks gathered by the end of each run.
</p>

<p>
  The efficiency of the agent's behavior will be determined by the contents of the inventory when the time limit is up. 
  Higher amounts of wood within the inventory will increase the reward given by the algorithm. 
  On the other hand, the presence of any leftover materials in the inventory will decrease the reward.
  We will verify that the project is working by making sure that the agent is:
  <ul>
      <li>
        committing to a tree to chop down
    </li>
      <li>
        chopping down entire trees
      </li>
      <li>
        leaving wood in the inventory
      </li>
  </ul>
</p>

<p>
  As the project becomes more complex, we hope to add the crafting of wooden axes into the agent's decision making process.
  When this is implemented, we will measure axe crafting efficiency by the amount of axes leftover when the time limit is up.
  If time allows us, we may also add stone axe crafting into the agent's toolset.
  As a result, this will introduce mining into the agent's learned behaviors.
  The goal would be for the agent to intelligently weigh the benefits of mining for a more efficient axe. 
  At that point, the agent's mining efficiency would be measured by the amount of leftover stone in the inventory when the time limit is up.
</p>

Appointment for project meeting: 21 October 2021 3:15pm-3:30pm
