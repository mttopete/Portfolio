---
layout: default
title:  Home
---

<img style="width:700px; height:auto" src="https://images.pexels.com/photos/4205986/pexels-photo-4205986.jpeg?auto=compress&cs=tinysrgb&dpr=3&h=750&w=1260" alt="Lumberjack Image">

<br>

<h2>About Our Project:</h2>
<p style="width:700px; height:auto">In our project, we leverage Malmo to train a Minecraft character (named Jack) to learn how to collect wood in an efficient and effective way within a landscape that consists of a number of separate islands populated by trees. He must not only learn how to gather wood, but how to maximize productivity by making optimal decisions about the variety of options that he faces. He must determine if it is a good idea to expend wood he has already gathered to produce planks to cross to another island to gain more wood. He must decide when to craft a new axe. By making use of a reinforcement learning model with convolutional layers, we help Jack learn how to be the best lumberjack that he can!</p>

<br>

<h2>Team Members:</h2>
<h4>Stuart McClintock</h4>
<h4>Anthony de Bem</h4>
<h4>Mateo Topete</h4>

<br>

Source code: https://github.com/StuartMcClintock/Lumberjacks


Reports:

- [Proposal](proposal.html)
- [Status](status.html)
- [Final](final.html)
